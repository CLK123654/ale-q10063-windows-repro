import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const toolsDir = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(toolsDir, "..");
const sourceDatabase = path.join(root, "database", "notify_control.db");
const windowPolicyPath = path.join(root, "rules", "window_policy.json");
const decisionPolicyPath = path.join(root, "rules", "decision_policy.csv");
const reportSchemaPath = path.join(root, "rules", "report_schema.json");
const outputDir = path.join(root, "output");
const outputDatabase = path.join(outputDir, "notify_plan.db");
const sqlFile = path.join(outputDir, "sql", "rebuild_notify_plan.sql");
const reportsDir = path.join(outputDir, "reports");
const sqliteExecutable = process.platform === "win32" ? "sqlite3.exe" : "sqlite3";

function cleanupGenerated() {
  fs.rmSync(outputDatabase, { force: true });
  fs.rmSync(reportsDir, { recursive: true, force: true });
}

function fail(message, code = 1) {
  cleanupGenerated();
  console.error(message);
  process.exit(code);
}

function sqlLiteral(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function runSql(database, sql, timeout = 30_000) {
  const result = spawnSync(sqliteExecutable, [database], {
    cwd: root,
    input: sql,
    encoding: "utf8",
    timeout,
    windowsHide: true,
  });
  if (result.error) fail(`无法执行SQLite命令行客户端：${result.error.message}`, 3);
  if (result.status !== 0) {
    if (result.stdout) process.stdout.write(result.stdout);
    if (result.stderr) process.stderr.write(result.stderr);
    fail(`SQLite执行失败，退出码${result.status}`, result.status || 4);
  }
  return result.stdout.trim();
}

function queryLines(database, sql) {
  const text = runSql(database, `.mode list\n.separator |\n${sql}\n`);
  return text === "" ? [] : text.split(/\r?\n/u);
}

function scalarFrom(database, sql) {
  return queryLines(database, sql)[0] ?? "";
}

function parseCsv(text) {
  const lines = text.replace(/^\uFEFF/u, "").trim().split(/\r?\n/u);
  return lines.map((line) => line.split(","));
}

function readJson(file, label) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    fail(`${label}不是有效JSON：${error.message}`, 2);
  }
}

function exportCsv(database, report) {
  const columns = report.columns.join(",");
  const orderBy = report.order_by.join(",");
  const sql = `SELECT ${columns} FROM ${report.table} ORDER BY ${orderBy}`;
  const result = spawnSync(sqliteExecutable, ["-header", "-csv", database, sql], {
    cwd: root,
    encoding: "utf8",
    timeout: 30_000,
    windowsHide: true,
  });
  if (result.error || result.status !== 0) {
    fail(`导出${report.path}失败：${result.stderr || result.error?.message || "未知错误"}`, 5);
  }
  const destination = path.join(outputDir, ...report.path.split("/"));
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.writeFileSync(destination, result.stdout, "utf8");
}

for (const [file, label] of [
  [sourceDatabase, "输入数据库"],
  [windowPolicyPath, "窗口规则"],
  [decisionPolicyPath, "裁决规则"],
  [reportSchemaPath, "报表规则"],
  [sqlFile, "完成版SQL"],
]) {
  if (!fs.existsSync(file)) fail(`${label}不存在：${file}`, 2);
}

const versionProbe = spawnSync(sqliteExecutable, ["--version"], {
  encoding: "utf8",
  timeout: 10_000,
  windowsHide: true,
});
if (versionProbe.error || versionProbe.status !== 0) fail("SQLite命令行客户端不可用", 3);
const sqliteVersion = String(versionProbe.stdout).trim().split(/\s+/u)[0];
const [major, minor] = sqliteVersion.split(".").map(Number);
if (!(major > 3 || (major === 3 && minor >= 40))) fail(`SQLite版本过低：${sqliteVersion}`, 3);

const windowPolicy = readJson(windowPolicyPath, "窗口规则");
const isoPattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/u;
if (
  !isoPattern.test(windowPolicy.report_start_utc)
  || !isoPattern.test(windowPolicy.report_end_utc)
  || !isoPattern.test(windowPolicy.fixed_now_utc)
  || windowPolicy.report_start_utc >= windowPolicy.report_end_utc
  || windowPolicy.campaign_cap_scope !== "report_window"
  || JSON.stringify(windowPolicy.daily_cap_scope) !== JSON.stringify(["user_id", "campaign_id", "utc_date"])
) fail("窗口规则缺少可用的时间或统计范围", 2);

const policyRows = parseCsv(fs.readFileSync(decisionPolicyPath, "utf8"));
const policyHeader = policyRows.shift();
const expectedReasons = [
  "unknown_user",
  "unknown_campaign",
  "already_delivered",
  "subscriber_paused",
  "manual_suppression",
  "tier_not_allowed",
  "quiet_hours",
  "duplicate_candidate",
  "user_daily_cap",
  "campaign_cap_reached",
  "send",
];
if (JSON.stringify(policyHeader) !== JSON.stringify(["rank", "reason", "detail"])) fail("裁决规则表头无效", 2);
if (
  policyRows.length !== expectedReasons.length
  || policyRows.some((row, index) => row.length !== 3 || Number(row[0]) !== index + 1 || row[1] !== expectedReasons[index] || row[2].trim() === "")
) fail("裁决规则次序或说明无效", 2);

const reportSchema = readJson(reportSchemaPath, "报表规则");
const expectedReports = [
  {
    name: "send_plan",
    table: "send_plan",
    path: "reports/send_plan.csv",
    columns: ["event_id", "user_id", "campaign_id", "channel", "requested_at_utc", "local_time", "provider_message_id", "send_priority", "action"],
    order_by: ["send_priority DESC", "requested_at_utc ASC", "event_id ASC"],
  },
  {
    name: "suppression_audit",
    table: "suppression_audit",
    path: "reports/suppression_audit.csv",
    columns: ["event_id", "user_id", "campaign_id", "channel", "requested_at_utc", "local_time", "reason", "detail"],
    order_by: ["requested_at_utc ASC", "event_id ASC"],
  },
  {
    name: "campaign_quota_report",
    table: "campaign_quota_report",
    path: "reports/campaign_quota_report.csv",
    columns: ["campaign_id", "channel", "daily_cap", "campaign_cap", "existing_sent_count", "planned_send_count", "suppressed_count", "remaining_after_plan"],
    order_by: ["campaign_id ASC"],
  },
];
if (JSON.stringify(reportSchema.reports) !== JSON.stringify(expectedReports)) fail("报表规则与运行入口不匹配", 2);

cleanupGenerated();
fs.mkdirSync(path.dirname(outputDatabase), { recursive: true });
fs.copyFileSync(sourceDatabase, outputDatabase);

const policyInserts = policyRows.map(([rank, reason, detail]) => (
  `INSERT INTO temp.decision_policy VALUES(${Number(rank)},${sqlLiteral(reason)},${sqlLiteral(detail)});`
));
const sqlRelative = path.relative(root, sqlFile).split(path.sep).join("/");
runSql(outputDatabase, [
  "PRAGMA foreign_keys=ON;",
  "CREATE TEMP TABLE run_contract(report_start_utc TEXT NOT NULL,report_end_utc TEXT NOT NULL,fixed_now_utc TEXT NOT NULL);",
  `INSERT INTO temp.run_contract VALUES(${sqlLiteral(windowPolicy.report_start_utc)},${sqlLiteral(windowPolicy.report_end_utc)},${sqlLiteral(windowPolicy.fixed_now_utc)});`,
  "CREATE TEMP TABLE decision_policy(rank INTEGER PRIMARY KEY,reason TEXT UNIQUE NOT NULL,detail TEXT NOT NULL);",
  ...policyInserts,
  `.read "${sqlRelative}"`,
].join("\n"));

for (const report of reportSchema.reports) exportCsv(outputDatabase, report);

const scalar = (sql) => queryLines(outputDatabase, sql)[0] ?? "";
const sourceTables = ["subscribers", "campaign_rules", "candidate_queue", "delivery_history", "suppression_overrides"];
const sourceUnchanged = sourceTables.every((table) => {
  const sourceSchema = scalarFrom(sourceDatabase, `SELECT sql FROM sqlite_schema WHERE type='table' AND name=${sqlLiteral(table)};`);
  const outputSchema = scalarFrom(outputDatabase, `SELECT sql FROM sqlite_schema WHERE type='table' AND name=${sqlLiteral(table)};`);
  const sourceRows = runSql(sourceDatabase, `.mode quote\nSELECT * FROM ${table} ORDER BY rowid;`);
  const outputRows = runSql(outputDatabase, `.mode quote\nSELECT * FROM ${table} ORDER BY rowid;`);
  return sourceSchema === outputSchema && sourceRows === outputRows;
});
const invariants = {
  candidate_coverage: Number(scalar("SELECT count(*)=count(DISTINCT event_id) AND count(*)=(SELECT count(*) FROM candidate_queue) FROM candidate_decision;")) === 1,
  send_suppression_partition: Number(scalar("SELECT (SELECT count(*) FROM send_plan)+(SELECT count(*) FROM suppression_audit)=(SELECT count(*) FROM candidate_queue);")) === 1,
  send_suppression_disjoint: Number(scalar("SELECT count(*) FROM send_plan JOIN suppression_audit USING(event_id);")) === 0,
  provider_ids_unique: Number(scalar("SELECT count(*)=count(DISTINCT provider_message_id) FROM send_plan;")) === 1,
  remaining_nonnegative: Number(scalar("SELECT count(*) FROM campaign_quota_report WHERE remaining_after_plan<0;")) === 0,
  source_tables_unchanged: sourceUnchanged,
  integrity_ok: scalar("PRAGMA integrity_check;") === "ok",
  foreign_keys_ok: queryLines(outputDatabase, "PRAGMA foreign_key_check;").length === 0,
};
if (!Object.values(invariants).every(Boolean)) fail("生成结果未通过数据库一致性检查", 7);

for (const report of reportSchema.reports) {
  const file = path.join(outputDir, ...report.path.split("/"));
  if (!fs.existsSync(file)) fail(`缺少报表：${report.path}`, 8);
}
if (!fs.existsSync(outputDatabase)) fail("缺少通知计划数据库", 8);

const sendCount = Number(scalar("SELECT count(*) FROM send_plan;"));
const suppressionCount = Number(scalar("SELECT count(*) FROM suppression_audit;"));
console.log(`SQLite通知裁决完成：发送${sendCount}条，抑制${suppressionCount}条`);
