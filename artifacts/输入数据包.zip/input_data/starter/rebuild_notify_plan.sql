-- 补全此文件并保存到output/sql/rebuild_notify_plan.sql
-- 需要重建候选裁决、发送计划、抑制审计、活动配额报告和运行元数据
PRAGMA foreign_keys=ON;

DROP TABLE IF EXISTS send_plan;
CREATE TABLE send_plan(
  event_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  campaign_id TEXT NOT NULL
);
